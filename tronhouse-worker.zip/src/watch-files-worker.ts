import { watchOriginalFiles } from './shoots/watcher'

watchOriginalFiles()
