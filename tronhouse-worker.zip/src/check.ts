import { downloadOrderImages } from './orders'

downloadOrderImages('6T1FPN9HA234').then(console.log)
