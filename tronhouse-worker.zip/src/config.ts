import { config } from 'dotenv'
import path from 'path'

config()

export const PHOTOSHOP_WORKER_DIR = process.env.PHOTOSHOP_WORKER_DIR || '/mnt/cloud_shared/System/photoshop-worker'
export const PRODUCTION_ASSETS_DIR = process.env.PRODUCTION_ASSETS_DIR || '/mnt/cloud_shared/Production/ProductionAssets'
export const LOGS_DIR = process.env.LOGS_DIR || path.join(PHOTOSHOP_WORKER_DIR, 'logs')
export const PHOTOSHOP_PATH = process.env.PHOTOSHOP_PATH || 'C:/Program Files/Adobe/Adobe Photoshop 2025/Photoshop.exe'
// Ensure directories exist
import { existsSync, mkdirSync } from 'fs'

if (!existsSync(LOGS_DIR)) {
  mkdirSync(LOGS_DIR, { recursive: true })
}

export const getAppEndpoint = () => {
  const endpoint = process.env.TRONHOUSE_APP_ENDPOINT || 'https://app-api.tronhouse.vn'
  if (!endpoint) {
    throw new Error('Please provide TRONHOUSE_APP_ENDPOINT env')
  }
  return endpoint
}

export const getAssetsDir = () => {
  if (process.env.NODE_ENV === 'test') {
    return path.resolve('src/tests/fixtures').replace(/\\/g, '/')
  }
  const assetsDir = process.env.TRONHOUSE_ASSETS_DIR
  if (!assetsDir) {
    throw new Error('Please provide TRONHOUSE_ASSETS_DIR env')
  }
  return assetsDir
}

export const getScriptsDir = () => {
  const assetsDir = getAssetsDir()
  return path.join(assetsDir, 'scripts')
}

export const getOriginalFilesPattern = () => {
  const pattern = process.env.TRONHOUSE_ORIGINAL_FILES_PATTERN
  if (!pattern) {
    throw new Error('Please provide TRONHOUSE_ORIGINAL_FILES_PATTERN env')
  }
  return pattern
}
