export default {
  collectCoverage: true,
}
